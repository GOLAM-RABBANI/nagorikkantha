<?php include('header.php');?>

<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <div class="col-sm-8">
                <img src="images/president.jpg" alt="President" class="img-responsive" style="width: 100%;">
                <h2><a href="single.php">মানস গঠনে শিক্ষার পাশাপাশি খেলাধুলা ও সংস্কৃতি চর্চার বিকল্প নেই</a></h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus animi autem est eum ex, molestiae mollitia optio placeat quaerat quas similique tempore ullam voluptatibus. Dignissimos ipsam ipsum quod recusandae sapiente.</p>
            </div>
            </div>
    </div>
</div>

<?php include ('footer.php');?>