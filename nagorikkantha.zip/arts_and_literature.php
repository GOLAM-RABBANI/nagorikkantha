<?php include('header.php');?>

    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="category-title">
                    <p><a href="">শিল্প ও সাহিত্য</a></p>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">

            <div class="col-sm-12" style="margin: 2.5em 0 0 0; padding: 0;">
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">
                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">মেয়র পদ বহাল থাকায় বুলবুলকে ছাত্রদলের অভিনন্দন</a></h3>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">

                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">মানস গঠনে শিক্ষার পাশাপাশি খেলাধুলা ও সংস্কৃতি চর্চার বিকল্প নেই</a></h3>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">

                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">ফিরে এসো # জাহাঙ্গীর বাবু</a></h3>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">

                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">মানস গঠনে শিক্ষার পাশাপাশি খেলাধুলা ও সংস্কৃতি চর্চার বিকল্প নেই</a></h3>
                    </div>
                </div>
            </div>
            <div class="col-sm-12" style="margin: 2.5em 0 0 0;padding: 0;">
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">

                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">মানস গঠনে শিক্ষার পাশাপাশি খেলাধুলা ও সংস্কৃতি চর্চার বিকল্প নেই</a></h3>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">

                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">মানস গঠনে শিক্ষার পাশাপাশি খেলাধুলা ও সংস্কৃতি চর্চার বিকল্প নেই</a></h3>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">

                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">মানস গঠনে শিক্ষার পাশাপাশি খেলাধুলা ও সংস্কৃতি চর্চার বিকল্প নেই</a></h3>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">

                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">মানস গঠনে শিক্ষার পাশাপাশি খেলাধুলা ও সংস্কৃতি চর্চার বিকল্প নেই</a></h3>

                    </div>
                </div>

            </div>
        </div>
    </div>


    <div class="container">
        <div class="row">

            <div class="col-sm-12" style="margin: 2.5em 0 0 0; padding: 0;">
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">
                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">মেয়র পদ বহাল থাকায় বুলবুলকে ছাত্রদলের অভিনন্দন</a></h3>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">

                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">মানস গঠনে শিক্ষার পাশাপাশি খেলাধুলা ও সংস্কৃতি চর্চার বিকল্প নেই</a></h3>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">

                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">ফিরে এসো # জাহাঙ্গীর বাবু</a></h3>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">

                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">মানস গঠনে শিক্ষার পাশাপাশি খেলাধুলা ও সংস্কৃতি চর্চার বিকল্প নেই</a></h3>
                    </div>
                </div>
            </div>
            <div class="col-sm-12" style="margin: 2.5em 0 0 0;padding: 0;">
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">

                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">মানস গঠনে শিক্ষার পাশাপাশি খেলাধুলা ও সংস্কৃতি চর্চার বিকল্প নেই</a></h3>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">

                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">মানস গঠনে শিক্ষার পাশাপাশি খেলাধুলা ও সংস্কৃতি চর্চার বিকল্প নেই</a></h3>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">

                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">মানস গঠনে শিক্ষার পাশাপাশি খেলাধুলা ও সংস্কৃতি চর্চার বিকল্প নেই</a></h3>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well well-sm" style="min-height: 21em;">

                        <div class="img-block">
                            <img src="images/sports.jpg" alt="Sports" class="img-responsive">
                        </div>

                        <h3><a href="">মানস গঠনে শিক্ষার পাশাপাশি খেলাধুলা ও সংস্কৃতি চর্চার বিকল্প নেই</a></h3>

                    </div>
                </div>

            </div>
        </div>
    </div>




<?php include ('footer.php');?>